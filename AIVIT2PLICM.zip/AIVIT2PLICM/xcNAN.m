function Uout=xcNAN(U)
[r,c] = size(U);
temp = isnan(U);
result_U = U;
for i=1:c
    for j=1:r
        if temp(j,i) == 1
            if  j==1
               result_U(j,i) = result_U(j+1,i); 
            else
                result_U(j,i) = result_U(j-1,i);
            end
        end
    end
end
Uout=result_U;