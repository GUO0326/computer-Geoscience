 %������
clear;
close all;
clc;
[I,data] = Mread();
rc=size(I(:,:,1));
data=data(:,1:3); %ֻȡǰ��������,(�е�ͼ���δ���3)----------2ά
I=I(:,:,1:3);%ֻȡǰ��������,(�е�ͼ���δ���3)------------------3ά
[m,n] = size(I(:,:,1));
[ddown,dup,means] = make_neiinterval(I,data);         %means--��׼��  
% %���乹�취1������3��3�������ڵķ����+-0.5���ı�׼������������ֵ���ݵ����½磻
% [std2] = solveStd_1(I);
% [means,std2] = solveStd(I);
% ddown=data-0.2.*std2;dup=data+0.2.*std2;
% [x,y]=size(data);
% for i=1:x
%     for j=1:y
%       if(ddown(i,j)<0)
%           ddown(i,j)=0;       
%       end
%       if(dup(i,j)>255)
%           dup(i,j)=255;       
%       end
%     end
% end

cluster_num=6;
  
% ��ʼ������������ ���ûҶ�ֱ��ͼ����
% center=huiduzhifangtu(data,ddown,dup,cluster_num);   %��ʼ�ľ������ģ�center---3ά��c��3��2��
% center=huiduzhifangtu_new1(data,cluster_num);%��ʼ����������V0---(c,3)
% % %��ʼ���������ķ���
center=zeros(cluster_num,3);
MeanK=mean(data);
for i=1:cluster_num
    for I=1:3
        center(i,I)=( (3*i)/(2*cluster_num) )*MeanK(I);
    end
end
% %�Զ����������(IndinaLine)
% center=[12,79,52;
%                 126,55,23;
%                 216,8,10;                        
%                 234,60,92;
%                 53,138,120;
%                 227,235,229];

t0=clock;
[center_new, U] = aivT2PLICM_1209(data,ddown,dup,center, means,rc);
disp(['��������ʱ�䣺',num2str(etime(clock,t0))]);

% %%%%ָ��
PC=sum(sum(U.^2))./(n*m);
fprintf('A-iv-IT2PLICM�㷨PCָ��Ϊ%f\n',PC);
PE=sum(sum(U.*log(U)))./(-1*m*n);
fprintf('A-iv-IT2PLICM�㷨PEָ��Ϊ%f\n',PE);
Min=inf;%��ʼ��Ϊ�����
for i=1:(cluster_num-1)
    for j=(i+1):cluster_num
        tp=sum((center_new(i,:)-center_new(j,:)).^2);
        Min=min(tp,Min);
    end
end
dist = distfcm(center_new, data);
% dist = adadistivflicm_new(center_new, data);
XB=sum(sum((U.^2).*(dist.^2)))./(m*n*Min);
fprintf('A-iv-IT2PLICM�㷨XBָ��Ϊ%f\n',XB);

      maxU =max(U);
      index1 = find(U(1,:) == maxU);
      index2 = find(U(2,:) == maxU);
      index3 = find(U(3,:) == maxU);
      index4 = find(U(4,:) == maxU);
      index5 = find(U(5,:) == maxU);
      index6 = find(U(6,:) == maxU);
%       index7 = find(U(7,:) == maxU);
%       index8 = find(U(8,:) == maxU);
%        index9 = find(U(9,:) == maxU);
%       index10 = find(U(10,:) == maxU);
      data(index1,1)=1;
      data(index2,1)=2;
      data(index3,1)=3;
      data(index4,1)=4;
      data(index5,1)=5;
      data(index6,1)=6;
%        data(index7,1)=7;
%       data(index8,1)=8;
%        data(index9,1)=9;
%       data(index10,1)=10;

dd=data(:,1);
B=zeros(m,n,3); %�յ�
% B(:,:,1) =uint8(abs(reshape(dd,m,n)));
B2=zeros(m,n);
B2(:,:) =abs(reshape(dd,m,n));
% % %�Զ���ɫ
% clims = [1 cluster_num];
% figure,
% imagesc(B2,clims); %�����ɫ
% axis equal   %�ȱ���������
% set(gca,'xtick',[],'ytick',[])  %ͬʱȥ��x��y��Ŀ̶�
% colormap(jet)


%��������ͼ
% for i=1:m
%     for j=1:n
%          if B2(i,j)==1 %����
%             B(i,j,1)=85;
%             B(i,j,2)=107;
%             B(i,j,3)=47;
%          end
%          if B2(i,j)==2 %ǳ��
%             B(i,j,1)=0;
%             B(i,j,2)=255;
%             B(i,j,3)=255;
%          end
%     end
% end
% figure,
% h3=imshow(uint8(B),'border','tight'); 
%  imwrite(h3.CData,'C:\Users\naoluilu\Desktop\�����仯���Լ�\Բ������\Բ������_��׼ͼ.bmp');  


% %%�������ͼ
% for i=1:m
%     for j=1:n
%         if B2(i,j)==1 %����
%             B(i,j,1)=0;
%             B(i,j,2)=0;
%             B(i,j,3)=1;
%         end
%          if B2(i,j)==4 %����
%             B(i,j,1)=0;
%             B(i,j,2)=1;
%             B(i,j,3)=1;
%          end
%          if B2(i,j)==2 %����
%             B(i,j,1)=0.1333;
%             B(i,j,2)=0.5414;
%             B(i,j,3)=0.1333;
%          end
%          if B2(i,j)==3 %ǳ��
%             B(i,j,1)=0;
%             B(i,j,2)=1;
%             B(i,j,3)=0;
%          end
%     end
% end
% figure,
% h3=imshow(B,'border','tight'); 
% % imwrite(h3.CData,'./AivIT2PLICM_Pentagon(K=0.1,��˹0.05).bmp');  
% % imwrite(h3.CData,'./AivIT2PLICM_Pentagon(K=0.1,����0.10).bmp');  
% imwrite(h3.CData,'./AivIT2PLICM_Pentagon(K=0.1,�ߵ�0.15).bmp');  

% %QB����
% for i=1:m
%     for j=1:n
%         if B2(i,j)==1 %����
%             B(i,j,1)=0;
%             B(i,j,2)=0;
%             B(i,j,3)=1;
%         end
%         if B2(i,j)==5 %��
%             B(i,j,1)=1;
%             B(i,j,2)=1;
%             B(i,j,3)=0;
%         end
%          if B2(i,j)==4 %��
%             B(i,j,1)=1;
%             B(i,j,2)=0;
%             B(i,j,3)=0;
%          end
%          if B2(i,j)==2 %��
%             B(i,j,1)=0.1333;
%             B(i,j,2)=0.5414;
%             B(i,j,3)=0.1333;
%          end
%          if B2(i,j)==3 %ǳ��
%             B(i,j,1)=0;
%             B(i,j,2)=1;
%             B(i,j,3)=0;
%          end
%     end
% end
% figure,
% h3=imshow(B,'border','tight'); 
% imwrite(h3.CData,'./AivIT2PLICM_QB����_4(k=1.5,m=1.4).bmp');  

% %TM����
% for i=1:m
%     for j=1:n
%         if B2(i,j)==1 %����
%             B(i,j,1)=0;
%             B(i,j,2)=0;
%             B(i,j,3)=1;
%         end
%         if B2(i,j)==2  %��
%             B(i,j,1)=1;
%             B(i,j,2)=1;
%             B(i,j,3)=0;
%         end
%          if B2(i,j)==3 %��
%             B(i,j,1)=1;
%             B(i,j,2)=0;
%             B(i,j,3)=0;
%          end
%          if B2(i,j)==4 %��
%             B(i,j,1)=0.1333;
%             B(i,j,2)=0.5414;
%             B(i,j,3)=0.1333;
%          end
%          if B2(i,j)==5 %����
%             B(i,j,1)=0;
%             B(i,j,2)=1;
%             B(i,j,3)=1;
%          end
%     end
% end
% figure,
% h3=imshow(B,'border','tight'); 
% imwrite(h3.CData,'./AivIT2PLCM_ZY3����_5(k=1,m=1.2).bmp');  

% %TM����
% for i=1:m
%     for j=1:n
%         if B2(i,j)==1 %����
%             B(i,j,1)=0;
%             B(i,j,2)=0;
%             B(i,j,3)=1;
%         end
%         if B2(i,j)==4  %��
%             B(i,j,1)=1;
%             B(i,j,2)=1;
%             B(i,j,3)=0;
%         end
%          if B2(i,j)==3 %��
%             B(i,j,1)=1;
%             B(i,j,2)=0;
%             B(i,j,3)=0;
%          end
%          if B2(i,j)==2 %��
%             B(i,j,1)=0.1333;
%             B(i,j,2)=0.5414;
%             B(i,j,3)=0.1333;
%          end
%          if B2(i,j)==5 %����
%             B(i,j,1)=0;
%             B(i,j,2)=1;
%             B(i,j,3)=1;
%          end
%     end
% end
% figure,
% % imshow(B,'border','tight','initialmagnification','fit');
% h3=imshow(B,'border','tight'); 
% imwrite(h3.CData,'./AivIT2PLCM_TM����_5(k=1.5,m=1.2).bmp');  


% %�߹���1--Indian-pines_part(40,30,20)
% for i=1:m
%     for j=1:n
%         if B2(i,j)==1 %����
%             B(i,j,1)=0;
%             B(i,j,2)=0;
%             B(i,j,3)=1;
%         end
%         if B2(i,j)==2  %ǳ��
%             B(i,j,1)=0;
%             B(i,j,2)=1;
%             B(i,j,3)=0;
%         end
%          if B2(i,j)==4 %��
%             B(i,j,1)=1;
%             B(i,j,2)=0;
%             B(i,j,3)=0;
%          end
%          if B2(i,j)==3 %��
%             B(i,j,1)=1;
%             B(i,j,2)=1;
%             B(i,j,3)=0;
%          end
% %          if B2(i,j)==5 %��
% %             B(i,j,1)=0;
% %             B(i,j,2)=0;
% %             B(i,j,3)=0;
% %          end
%     end
% end
% figure,
% % imshow(B,'border','tight','initialmagnification','fit');
% h3=imshow(B,'border','tight');  %figure�����У�ͼƬ���ܲ����հ�
% imwrite(h3.CData,'./AivIT2PLCM_Indian-pines_part(k=1.5,m=1.1).bmp');  

% %�߹���1--pavia_U
% for i=1:m
%     for j=1:n
%         if B2(i,j)==1 %����
%             B(i,j,1)=0;
%             B(i,j,2)=0;
%             B(i,j,3)=1;
%         end
%         if B2(i,j)==2 %����
%             B(i,j,1)=0;
%             B(i,j,2)=1;
%             B(i,j,3)=1;
%         end
%         if B2(i,j)==3  %��ɫ
%             B(i,j,1)=1;
%             B(i,j,2)=0;
%             B(i,j,3)=0;
%         end
%          if B2(i,j)==4  %��
%             B(i,j,1)=1;
%             B(i,j,2)=1;
%             B(i,j,3)=0;
%         end
%         if B2(i,j)==5  %����
%              B(i,j,1)=0.13333;        
%              B(i,j,2)=0.5414;          
%              B(i,j,3)=0.13333;  
%         end
%         if B2(i,j)==6  %��ɫ
%             B(i,j,1)=1;
%             B(i,j,2)=0;
%             B(i,j,3)=1;
%         end
%     end
% end
% figure,
% % imshow(B,'border','tight','initialmagnification','fit');
% h3=imshow(B,'border','tight');  %figure�����У�ͼƬ���ܲ����հ�
% % imwrite(h3.CData,'./AivIT2PLICM_PaviaU(K=0.001,m=1.3).bmp');  

% %�߹���1--pavia_U
% for i=1:m
%     for j=1:n
%         if B2(i,j)==1 %����
%             B(i,j,1)=0;
%             B(i,j,2)=0;
%             B(i,j,3)=1;
%         end
%         if B2(i,j)==2 %����
%             B(i,j,1)=0;
%             B(i,j,2)=1;
%             B(i,j,3)=1;
%         end
%         if B2(i,j)==3  %��ɫ
%             B(i,j,1)=1;
%             B(i,j,2)=0;
%             B(i,j,3)=0;
%         end
%          if B2(i,j)==4  %��
%             B(i,j,1)=1;
%             B(i,j,2)=1;
%             B(i,j,3)=0;
%         end
%         if B2(i,j)==5  %����
%              B(i,j,1)=0.13333;        
%              B(i,j,2)=0.5414;          
%              B(i,j,3)=0.13333;  
%         end
%         if B2(i,j)==6  %��ɫ
%             B(i,j,1)=1;
%             B(i,j,2)=0;
%             B(i,j,3)=1;
%         end
%     end
% end
% figure,
% % imshow(B,'border','tight','initialmagnification','fit');
% h3=imshow(B,'border','tight');  %figure�����У�ͼƬ���ܲ����հ�
% imwrite(h3.CData,'./AivIT2PLICM_PaviaU(K=1.5,m=1.3).bmp');  

% %�߹���1--Urban
for i=1:m
    for j=1:n
        if B2(i,j)==3 %��ɫ111111
            B(i,j,1)=1;
            B(i,j,2)=1;
            B(i,j,3)=0;
        end
        if B2(i,j)==4  %��ɫ(51,102,179)1111
            B(i,j,1)=0.27451;
            B(i,j,2)=0.5098;
            B(i,j,3)=0.70588;
        end
        if B2(i,j)==2  %��ɫ1111
            B(i,j,1)=1;
            B(i,j,2)=0;
            B(i,j,3)=0;
        end
        if B2(i,j)==5 %�̰�111111
            B(i,j,1)=0;
            B(i,j,2)=1;
            B(i,j,3)=1;
        end
        if B2(i,j)==1    %ǳ��1111
            B(i,j,1)=0;
            B(i,j,2)=1;
            B(i,j,3)=0;
        end
        if B2(i,j)==6  %��ɫ111111
            B(i,j,1)=0;
            B(i,j,2)=0;
            B(i,j,3)=1;
        end
    end
end
figure,
% imshow(B,'border','tight','initialmagnification','fit');
h3=imshow(B,'border','tight');  %figure�����У�ͼƬ���ܲ����հ�
imwrite(h3.CData,'C:\Users\naoluilu\Desktop\�������Լ�\Urban_lines\Urban_lines_Speckle\Urban_lines�ߵ�0.18\AivIT2PLICM_Urban(K=1,�ߵ�0.18).bmp');    %ֱ�ӱ����img���ߴ���ֱ��ʲ���


% % B=B2;
% % %С����     
%  for i=1:m 
%      for j=1:n      
%           if B2(i,j)==3       %ī��(�ֵ�) 3
%              B(i,j,1)=0.13333;        
%              B(i,j,2)=0.5414;          
%              B(i,j,3)=0.13333;    
%           end
%           if B2(i,j)==1  %ˮ(��ɫ)
%           B(i,j,1)=0;  
%           B(i,j,2)=0;
%           B(i,j,3)=1;
%           end
%           if B2(i,j)==5  %���(����)
%              B(i,j,1)=1;
%              B(i,j,2)=0;
%              B(i,j,3)=0;
%          end
%          if B2(i,j)==4   %ǳ��(�ݵ�)  4
%             B(i,j,1)=0;   
%             B(i,j,2)=1;
%             B(i,j,3)=0;  
%          end
%        if B2(i,j)==2      %��ɫ(ũ��)  2
%           B(i,j,1)=0;  
%           B(i,j,2)=0;
%           B(i,j,3)=0;
%        end
%     
%     end
% 
% end
% figure,
% % imshow(B,'border','tight','initialmagnification','fit');
% h3=imshow(B,'border','tight');  %figure�����У�ͼƬ���ܲ����հ�
% imwrite(h3.CData,'./AivIT2PLICMС����(K=2).bmp');    %ֱ�ӱ����img���ߴ���ֱ��ʲ��� 

% %��ƽ    
%  for i=1:m 
%      for j=1:n      
%           if B2(i,j)==5 || B2(i,j)==6    %ǳ��(����)
% %           if B2(i,j)==5   %ǳ��(����)
%              B(i,j,1)=0;        
%              B(i,j,2)=1;          
%              B(i,j,3)=1;    
%           end
%           if B2(i,j)==1  %ˮ(��ɫ)
%           B(i,j,1)=0;  
%           B(i,j,2)=0;
%           B(i,j,3)=1;
%           end
%           if B2(i,j)==2  %����(�ֵ�)
%              B(i,j,1)=0.13333;
%              B(i,j,2)=0.5451;
%              B(i,j,3)=0.13333;
%          end
%          if B2(i,j)==4       %��(���)
%             B(i,j,1)=1;   
%             B(i,j,2)=0;
%             B(i,j,3)=0;  
%          end
%        if B2(i,j)==3       %ǳ��(�ݵ�)
%           B(i,j,1)=0;  
%           B(i,j,2)=1;
%           B(i,j,3)=0;
%        end
% %           if B2(i,j)==6         %��ɫ
% %              B(i,j,1)=0;        
% %              B(i,j,2)=0;          
% %              B(i,j,3)=0;    
% %           end
%     end
% 
% end
% figure,
% % imshow(B,'border','tight','initialmagnification','fit');
% h3=imshow(B,'border','tight');  %figure�����У�ͼƬ���ܲ����հ�
% imwrite(h3.CData,'./AivIT2PLICM��ƽ(K=1.5)-6.bmp');    %ֱ�ӱ����img���ߴ���ֱ��ʲ��� 

% %�麣   
%  for i=1:m 
%      for j=1:n 
%          if B2(i,j)==6         %��ɫ(����)
%              B(i,j,1)=1;        
%              B(i,j,2)=0;          
%              B(i,j,3)=0;    
%           end
%           if B2(i,j)==5         %ǳ��(ũҵ�õ�)
%              B(i,j,1)=0;        
%              B(i,j,2)=1;          
%              B(i,j,3)=1;    
%           end
%           if B2(i,j)==2  %ˮ(��ɫ)
%           B(i,j,1)=0;  
%           B(i,j,2)=0;
%           B(i,j,3)=1;
%           end
%           if B2(i,j)==3  %����(�ֵ�)
%              B(i,j,1)=0.13333;
%              B(i,j,2)=0.5451;
%              B(i,j,3)=0.13333;
%          end
%          if B2(i,j)==4   %ǳ��(�����̵�)
%             B(i,j,1)=0;   
%             B(i,j,2)=1;
%             B(i,j,3)=0;  
%          end
%        if B2(i,j)==1       %��ɫ(̲Ϳ)
%           B(i,j,1)=0.41176;  
%           B(i,j,2)=0.41176;
%           B(i,j,3)=0.41176;
%        end
% %        if B2(i,j)==1       %��ɫ(̲Ϳ)
% %           B(i,j,1)=0;  
% %           B(i,j,2)=0;
% %           B(i,j,3)=0;
% %        end
%     end
% 
% end
% figure,
% %  imshow(B,'border','tight','initialmagnification','fit');
% h3=imshow(B,'border','tight');  %figure�����У�ͼƬ���ܲ����հ�
% imwrite(h3.CData,'./AivIT2PLICM�麣(K=1.5).bmp');    %ֱ�ӱ����img���ߴ���ֱ��ʲ��� 

% % �����     
%  for i=1:m 
%      for j=1:n      
%           if B2(i,j)==4         %ǳ��(ũҵ�õ�)
%              B(i,j,1)=0;        
%              B(i,j,2)=1;          
%              B(i,j,3)=1;    
%           end
%           if B2(i,j)==1  %ˮ(��ɫ)
%           B(i,j,1)=0;  
%           B(i,j,2)=0;
%           B(i,j,3)=1;
%           end
%           if B2(i,j)==3  %ǳ��(�����õ�)
%              B(i,j,1)=0;
%              B(i,j,2)=1;
%              B(i,j,3)=0;
%          end
%          if B2(i,j)==5   %��(�����õ�)
%             B(i,j,1)=1;   
%             B(i,j,2)=0;
%             B(i,j,3)=0;  
%          end
%        if B2(i,j)==2       %����(�ֵ�)
%           B(i,j,1)=0.13333;  
%           B(i,j,2)=0.5451;
%           B(i,j,3)=0.13333;
%        end
%     
%     end
% 
% end
% figure,
% imshow(B,'border','tight','initialmagnification','fit');
% h3=imshow(B,'border','tight');  %figure�����У�ͼƬ���ܲ����հ�
% imwrite(h3.CData,'./AivIT2FLICM�����.bmp');    %ֱ�ӱ����img���ߴ���ֱ��ʲ��� 

% % % �ú�԰    
%  for i=1:m 
%      for j=1:n      
%           if B2(i,j)==3         %ǳ��(�ݵ�)
%              B(i,j,1)=0;        
%              B(i,j,2)=1;          
%              B(i,j,3)=0;    
%           end
%           if B2(i,j)==1  %ˮ(��ɫ)
%           B(i,j,1)=0;  
%           B(i,j,2)=0;
%           B(i,j,3)=1;
%           end
%           if B2(i,j)==5 ||  B2(i,j)==6 %��ɫ(����)
%              B(i,j,1)=1;
%              B(i,j,2)=0;
%              B(i,j,3)=0;
%          end
%          if B2(i,j)==2   %����(�ֵ�)
%             B(i,j,1)=0.13333;   
%             B(i,j,2)=0.5451;
%             B(i,j,3)=0.13333;  
%          end
%        if B2(i,j)==4      %(ǳ��)���
%           B(i,j,1)=0;  
%           B(i,j,2)=1;
%           B(i,j,3)=1;
%        end
% %           if B2(i,j)==6         %��ɫ
% %              B(i,j,1)=0;        
% %              B(i,j,2)=0;          
% %              B(i,j,3)=0;    
% %           end
%     end
% 
% end
% figure,
% imshow(B,'border','tight','initialmagnification','fit');
% h3=imshow(B,'border','tight');  %figure�����У�ͼƬ���ܲ����հ�
% imwrite(h3.CData,'./AivIT2PLICM�ú�԰(K=1.5)-6.bmp');    %ֱ�ӱ����img���ߴ���ֱ��ʲ��� 

% % %�¼�   
%  for i=1:m 
%      for j=1:n      
%           if B2(i,j)==1         %��ɫ(ũ��)
%              B(i,j,1)=0;        
%              B(i,j,2)=0;          
%              B(i,j,3)=0;    
%           end
%           if B2(i,j)==4  %ˮ(��ɫ)
%           B(i,j,1)=0;  
%           B(i,j,2)=0;
%           B(i,j,3)=1;
%           end
% %           if B2(i,j)==1 || B2(i,j)==3 %����(�����̵�)
%           if B2(i,j)==2
%              B(i,j,1)=0.13333;
%              B(i,j,2)=0.5451;
%              B(i,j,3)=0.13333;
%           end
%           if B2(i,j)==3       %(ǳ��)�ݵ�
%               B(i,j,1)=0;  
%               B(i,j,2)=1;
%               B(i,j,3)=0;
%           end
%          if B2(i,j)==5         
%              B(i,j,1)=1;        
%              B(i,j,2)=0;          
%              B(i,j,3)=0;    
%           end
%     end
% 
% end
% figure,
% h3=imshow(B,'border','tight');  %figure�����У�ͼƬ���ܲ����հ�
% imwrite(h3.CData,'./AivIT2PLICM�¼�(K=1.5).bmp');    %ֱ�ӱ����img���ߴ���ֱ��ʲ��� 
