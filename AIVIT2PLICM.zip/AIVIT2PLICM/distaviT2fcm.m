% function [out] = distaviT2fcm(center_w, center_m,d_w,d_m)
function [out] = distaviT2fcm(center,ddown,dup)
%%%%%%���Ӻ���adadistivfcm()����һ�£�

center_L=center(:,:,1);
center_R=center(:,:,2);
[cluster_n,cluster_m]=size(center_L);


% for i=1:cluster_n
%     for j=1:cluster_m
%             if(center_L(i,j)<=center_R(i,j))                
%             else
%                 tep=center_L(i,j);
%                 center_L(i,j)=center_R(i,j);
%                 center_R(i,j)=tep;
%             end           
%     end
% end
center_w=0.5*(center_R-center_L);
center_m=0.5*(center_R+center_L);

for i=1:cluster_n
    for j=1:cluster_m
            if(center_w(i,j)<0)                
                 center_w(i,j)=0;
            end           
    end
end


dup=double(dup);
ddown=double(ddown);

d_w=0.5*(dup-ddown);
d_m=0.5*(dup+ddown);

out = zeros(size(center_m, 1), size(d_m, 1));
for k = 1:size(center_m, 1), % ��ÿһ����������
%     % ÿһ��ѭ��������������㵽һ���������ĵľ���
    out(k, :) = sqrt(  sum(((d_m-ones(size(d_m,1),1)*center_m(k,:)).^2)',1)  + (1/3)*sum(((d_w-ones(size(d_w,1),1)*center_w(k,:)).^2)',1));
   
end



