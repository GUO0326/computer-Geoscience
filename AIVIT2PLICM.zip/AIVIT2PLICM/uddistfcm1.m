function [out] = uddistfcm1(rc,U,expo,dist_u)
%���G���� ud

m=rc(1);
n=rc(2);
cluster_n=size(U,1);

G=zeros(m,n,cluster_n);
for k=1:cluster_n
        for i=2:m-1
            for j=2:n-1
                tp=0.0;
                for i1=-1:1
                    for j1=-1:1
                        if ((i+i1)~=i)||((j+j1~=j))
                            t1=(j+j1-1)*m+(i+i1);
                                tp=tp+(((1-U(k,t1)).^expo)./(sqrt(i1.^2 + j1.^2) +1)).*(dist_u(k,t1).^2) ;
                        end
                    end
                end
                G(i,j,k)=tp;
            end
        end
end

out=zeros(cluster_n,m*n);
for j=1:cluster_n
    out(j,:)=reshape(G(:,:,j),1,m*n); 
end


